package com.sesion04;

public class SmartDevice {

    private int memoriaram;
    private int nucleosprocesador;
    private double yearfabricacion;


    public SmartDevice() {
        //lo creo vacio para que no de x culo
    }

    //metodo de la clase
    public SmartDevice(int memoriaram, int nucleosprocesador, double yearfabricacion) {
        this.memoriaram = memoriaram;
        this.nucleosprocesador = nucleosprocesador;
        this.yearfabricacion = yearfabricacion;
    }
}
