package com.sesion04;

public class Main {

    public static void main(String[] args) {

    SmartPhone iphone8 = new SmartPhone(8,4,1920);
    SmartWatch applewatch4 = new SmartWatch(2,4,2020,2,"Rojo");
        System.out.println("ahi lo llevas");
    }
}
