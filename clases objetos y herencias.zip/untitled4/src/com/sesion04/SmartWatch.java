package com.sesion04;

public class SmartWatch extends SmartDevice{

   int tipodehora;
   String colordepulsera;

    public SmartWatch(int tipodehora, String colordepulsera) {
        this.tipodehora = tipodehora;
        this.colordepulsera = colordepulsera;
    }

    public SmartWatch(int memoriaram, int nucleosprocesador, double yearfabricacion, int tipodehora, String colordepulsera) {
        super(memoriaram, nucleosprocesador, yearfabricacion);
        this.tipodehora = tipodehora;
        this.colordepulsera = colordepulsera;
    }
}
