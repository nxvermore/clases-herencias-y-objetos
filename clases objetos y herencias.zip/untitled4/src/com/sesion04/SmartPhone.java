package com.sesion04;

public class SmartPhone extends SmartDevice{

    public SmartPhone(int memoriaram, int nucleosprocesador, double yearfabricacion) {
        super(memoriaram, nucleosprocesador, yearfabricacion);
    }

    public static void main(String[] args) {

        int pulgadas;
        int telefonomovil;
        String colorfunda;


    }
}
